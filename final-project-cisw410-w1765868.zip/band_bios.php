<?php
$title = "Band Biographies";
include('header.php');
require_once("dbconnect.php");

if($_GET['bandName'] != "")
{
  $bandName = urldecode($_GET['bandName']);
}
else
{
  echo '<h3>* No band name provided for lookup.</h3>';
  echo '<a href="bands.php">Go back to Bands Page</a>';
}

$sql = "SELECT `bandName`, `biography`, `image`, `thumbnail` 
        FROM bands
        WHERE bandName = :bandName";

$stmnt = $dbc->prepare($sql);
$stmnt->bindValue(":bandName", $bandName);
$stmnt->execute();

while($row = $stmnt->fetch())
{
  $bn   = $row['bandName'];
  $bio  = $row['biography'];
  $img  = $row['image'];
  $tn   = $row['thumbnail'];


  echo '<div class="container">';
  echo '<div class="bandheader">' . $bn . '</div>';

  // echo '<h2>' . $bn . '</h2>';
  // echo '<p><img class="resize bandimg" src="images/' . $img . '" /></p>';
  

  echo '<div class="bandarticlecontainer">';
  echo '<div class="band-article">';
  echo '<p><img class="resize bandimg" src="images/' . $img . '" /></p>';
  echo '<p>' . $bio . '</p>';
  echo '</div>';
  echo '</div>';

  echo '</div>'; // class="container"
}

?>

<?php include("footer.php"); ?>