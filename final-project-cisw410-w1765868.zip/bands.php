<?php
$title = "Bands";
$heading = "Band Biographies";

include('header.php');
?>


<div class="container">

<div class="heading">
<h1><?php echo $heading; ?></h1>
</div>

<?php
require_once("dbconnect.php");


$sql = "SELECT `bandName`, `thumbnail`
        FROM bands
        ORDER BY `bandName` ASC";
$stmnt = $dbc->prepare($sql);
$stmnt->execute();
$allbands = $stmnt->fetchAll();



# build links for band info listing by looping through array of bands.
// echo '<div class="banddiv">' . "\n";
    
// build array of band names.
$count = 1;
foreach($allbands as $b)
{
    $maxcols = 3;
    if($count == 1) { echo "<div class='bandsrow'>\n"; }
    
    $bandName = $b['bandName'];
    $tn       = $b['thumbnail'];

    echo "\t<div class='bandscolumn'>\n";
    echo "\t\t" . '<a href="band_bios.php?bandName=' . urlencode($bandName) . '">' . '<img class="bandimg band-img" src="images/' . $tn . '" /></a><br><br>';
    echo "\t\t" . '<a class="bandhref" href="band_bios.php?bandName=' . urlencode($bandName) . '">' . $bandName . '</a>' . "\n";
    echo "\t</div>\n";

    if($count == $maxcols)
    { 
        echo "</div>\n";
        $count = 0;
    }
    $count++;
}
?>

</div> <!-- container -->



<?php
include('footer.php')
?>