<?php
echo "<div class='padandcentered'>";
echo "  <a id='go-back-href' href='admin_listtables.php'>Go Back To Main Admin Menu</a>";
echo "</div>";
?>