<?php
$title = $heading = "About Us";
include('header.php');
?>


<div class="container">
<h1><?php echo $heading ?></h1>
<div class="centeredcontainer">
<div class="aboutdiv">
At Concert @ The Creek, we strive to put fans first. 
Every day we're listening to your feedback and working to improve your experience before, during, 
and after events.

</div> <!-- aboutdiv -->
</div> <!-- centeredcontainer -->
</div> <!-- container -->


<?php
include('footer.php')
?>