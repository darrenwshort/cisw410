<?php
$heading = $title = "Delete record from 'events' table";
include("admin_header.php");
include('admin_gobacktomainmenulink.php');
?>







<?php
include('admin_gobacktomainmenulink.php');
include("admin_footer.php");
?>