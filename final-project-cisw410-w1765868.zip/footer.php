

</body>

<!-- close div tag, class="wrapper" located in header.php -->
</div>

<footer>
 [ @ The Creek ]  &copy; <?php echo "2018 - " . date('Y'); ?>
</footer>

</html>
