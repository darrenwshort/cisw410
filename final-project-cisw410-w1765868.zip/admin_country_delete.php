<?php
$title = $heading = "Delete record from 'country' table";
include('admin_header.php');
include('admin_gobacktomainmenulink.php');
?>


<h3>Under Construction</h3>
<?php 
include('admin_gobacktomainmenulink.php');
include('admin_footer.php');
?>