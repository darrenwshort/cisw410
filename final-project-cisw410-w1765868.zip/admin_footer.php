

</div> <!-- end div wrapper class -->
</body>

<footer>
 &copy; <?php echo "2018 - " . date('Y'); ?>
</footer>

</html>