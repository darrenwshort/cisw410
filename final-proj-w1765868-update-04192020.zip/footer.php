

</body>

<!-- close div tag, class="wrapper" located in header.php -->
</div>

<footer>
 [ Concert @ The Creek ]  &copy; <?php echo "2018 - " . date('Y'); ?>
</footer>

</html>
