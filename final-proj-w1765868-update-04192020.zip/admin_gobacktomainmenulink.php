<?php
echo "<div class=\"padandcentered\">";
echo "<button class=\"go-back-href\" onclick=\"javascript:location.href='admin_listtables.php';\">Back To Main Admin Menu</button>";
echo "</div>";
?>