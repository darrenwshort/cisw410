<?php
$title = $heading = "Add New Genre";
include('admin_header.php');
?>

<h3>Under Construction</h3>
<?php 
  include('admin_footer.php');
?>