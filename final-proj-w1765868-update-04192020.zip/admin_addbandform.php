<?php
$title = $heading = "Add New Band";
include('admin_header.php');
?>

<!-- <form method="post" action="addband.php">

</form> -->


<h3>Under Construction</h3>

<?php 
  include('admin_gobacktomainmenulink.php');
  include('admin_footer.php');
?>